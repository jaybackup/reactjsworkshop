import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const LoginCompo = () => {
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    let logindata = async()=>{
        console.log("Called");
        console.log("uname inside function",username);
        console.log("Password inside function",password);
        // let UserData =await fetch("http://localhost:8000/users?name=username&password=password")
        let UserData =await fetch("http://localhost:8000/users?name="+username+"&password="+password)
        UserData =await UserData.json()
        
        console.log(UserData);

        // axios.post('http://localhost:8000/users')
        //     .then(function (response) {
        //         console.log(response);
        //     })
        //     .catch(function (error) {
        //         console.log(error);
        //     });
    }
    return (
        <>
        <div className="container">
            <div className="row mt-5">
                <div className="col-4 offset-4">

            <div className="card">
                <div className="card-header text-center">Login</div>
                <div className="card-body">
                    <div className="row">
                        <div className="col">
                            <input type="text" className='form-control' placeholder='Enter User Name' name="" id="" onChange={(event) => { setUsername(event.target.value); }} />
                        </div>
                    </div>
                    <div className="row my-3">
                        <div className="col">
                            <input type="password" className='form-control' placeholder='Enter Password' name="" id="" onChange={(event) => { setPassword(event.target.value); }} />
                        </div>
                    </div>
                    <div className="row my-3">
                        <div className="col text-center">
                            <p>

                            {/* {"username "+username +" password "+password} */}
                            </p>
                            <input type="button" className='btn btn-primary' onClick={logindata} value="Login" name="" id="" />&nbsp;
                            <input type="button" className='btn btn-danger' value="Reset" name="" id="" />
                            <p className='mt-2'><Link to='/registration'>Create New Account</Link></p>
                        </div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </div>
        </>
    );
};

export default LoginCompo;