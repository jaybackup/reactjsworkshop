import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const LoginCompo = () => {
    const [username, setUsername] = useState("")
    const [password, setPassword] = useState("")
    let savedata = () => {
        console.log("called");
        axios.post('http://localhost:8000/users', {
            name: username,
            password: password
        })
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    return (
        <>
            <div className="container mt-5">
                <input type="text" className='form-control' placeholder='Enter User Name' name="" id="" onChange={(event) => { setUsername(event.target.value); }} />
                {username}
                <input type="password" className='form-control' placeholder='Enter Password' name="" id="" onChange={(event) => { setPassword(event.target.value); }} />
                {password}
                <input type="button" className='btn btn-primary' value='Register' name="" id="" onClick={savedata} />

            </div>
        </>
    );
};

export default LoginCompo;
// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';

// const LoginCompo = () => {
//     const [username,setUsername] = useState("")
//     const [password,setPassword] = useState("")
//     let savedata = ()=>{
//         console.log("called");
//     }
//     return (
//         <>
//         <div className="container">
//             <div className="row mt-5">
//                 <div className="col-4 offset-4">

//             <div className="card">
//                 <div className="card-header text-center">Registration</div>
//                 <div className="card-body">
//                     <div className="row">
//                         <div className="col">
//                             {/* <input type="text" className='form-control' placeholder='Enter User Name' name="" id="" onChange={(event)=>{ console.log(event); }} /> */}
//                             {/* <input type="text" className='form-control' placeholder='Enter User Name' name="" id="" onChange={(event)=>{ console.log(event.target); }} /> */}
//                             <input type="text" className='form-control' placeholder='Enter User Name' name="" id="" onChange={(event)=>{ setUsername(event.target.value); }} />
//                             {username}
//                         </div>
//                     </div>
//                     <div className="row my-3">
//                         <div className="col">
//                             <input type="password" className='form-control' placeholder='Enter Password' name="" id="" />
//                         </div>
//                     </div>
//                     <div className="row my-3">
//                         <div className="col text-center">
//                             <input type="button" className='btn btn-primary' onClick={savedata} value="Register" name="" id="" />&nbsp;
//                             <input type="button" className='btn btn-danger' value="Reset" name="" id="" />
//                         </div>
//                     </div>
//                 </div>
//             </div>
//                 </div>
//             </div>
//         </div>
//         </>
//     );
// };

// export default LoginCompo;