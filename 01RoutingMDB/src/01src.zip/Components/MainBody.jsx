import React from 'react';

const MainBody = () => {
    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-4">
                        <div class="card">
                            <img src="https://lh3.googleusercontent.com/spp/AOgFAqN-Y-Qks9Qo0okKjdRg2NjXQJsvWvsikiXx4pVPEh8qIWTX62rIc-yl0Yx0wN7tHZ2XFtl9T4dZAl_mHekUAJ5dw3n4Js0jPv2jYeUON2S5JqhgN7tj8Xp5yUW0rqW4f_Ptu1oQcS24ThVp3WpdrjztpUKFbn1dlBbfjqX--6cS4FKTJR2DAFtLLDEpgV0Lknj_4rZ4qzU=s512-rw-pd-pc0x00ffffff" class="card-img-top" alt="..." />
                                <div class="card-body">
                                    <h5 class="card-title">Card title</h5>
                                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                                    <a href="#" class="btn btn-primary">Go somewhere</a>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MainBody;